from django.apps import AppConfig


class RecomendacaoConfig(AppConfig):
    name = 'recomendacao'
