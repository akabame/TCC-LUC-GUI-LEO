from django.db import models
import pandas as pd
import json
import operator
class pagerank():
    def __init__(self):
        with open('/home/tccllb/rank.txt') as json_file:
            self.data = json.load(json_file)
        self.max =max(self.data.items(), key=operator.itemgetter(1))[0]
        for i in self.data:
            #fator 5 para range do PG variar entre 0 e 0.2
            self.data[i]=self.data[i]/((self.data[self.max])*5)
    def ordena(self,vet):
        self.modelo={}
        for i in vet:
            try:
                self.modelo[i]=self.data[i]
            except:
                print(i)
        self.sort_orders = sorted(self.modelo.items(), key=lambda x: x[1], reverse=True)
        retorno=[]
        for i in self.sort_orders:
            retorno.append(i[0])
        return retorno
        

