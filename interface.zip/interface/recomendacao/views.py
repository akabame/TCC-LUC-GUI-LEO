from django.shortcuts import render
from django.http import HttpResponse
from gensim.models import Word2Vec
import json
import numpy as np
import math
from recomendacao.models import pagerank
from tqdm import tqdm
from scipy import spatial
import operator

# Create your views here.

def home(request):
    global model
    global larray
    global glob
    global page
    page = pagerank()
    model = Word2Vec.load("/home/tccllb/w2v_model_total")
    larray = np.load("/home/tccllb/w2v_tfidf_array.npy",allow_pickle=True)
    with open('/home/tccllb/ocorrencia_global.txt') as outfile1:
        glob = json.load(outfile1)
    return render(request,'home.html',{'name':'Guilherme'})

def recomendacao(f):
    global larray
    global page
    docs = []
    sim_doc = {}
    outs = 0
    for i in tqdm(range(len(larray)),'calculando semelhança'):
        cos_sim = 1 - spatial.distance.cosine(f,larray[i][1])
        try:
            sim_doc[larray[i][0]] = cos_sim + page.data[larray[i][0].split('#')[0].replace(',','/')]
        except:
            try:
                sim_doc[larray[i][0]] = cos_sim + page.data[larray[i][0].split('#')[0]]
            except:
                outs = outs + 1
                pass
    print('outs: ' + str(outs))
    order = sorted(sim_doc.items(),key=operator.itemgetter(1),reverse=True)
    docs = order[:10]
    result = []
    for i in docs:
        result.append(i[0])
    paginas = page.ordena(result)
    return paginas

def assunto(request):
    result2 = ['Erro']
    dic_frase = {}
    frase_acc = 0
    tf_acc = 0
    result_link = []
    try:    
        frase = request.GET["assunto_text"]
        palavras = frase.split(' ')
        for i in palavras:
            dic_frase[i] = 0
        for i in palavras:
            dic_frase[i] = dic_frase[i] + 1
        for i in palavras:
            tfidf = dic_frase[i] * math.log(839342/glob[i])
            frase_acc = frase_acc + (model.wv[i] * tfidf)
            tf_acc = tf_acc + tfidf
    
        #divisao por zero
        if tf_acc == 0:
            tf_acc = 1
    
        frase_final = frase_acc/tf_acc
        result = recomendacao(frase_final)
        result_link = []
        for i in range(len(result)):
            result[i] = result[i].replace('%C3%A9','é').replace('%C3%B4','ô').replace('%C3%A3','ã').replace('%C3%A7','ç').replace('%C3%AD','í').replace('%C3%A1','á').replace('%C3%B3','ó').replace('%C3%BA','ú').replace('%C3%B5','õ').replace('%C3%A2','â').replace('%C3%87','ć').replace('%C3%AA','ê').replace('%C8%99','ș').replace('%C3%8D','Í').replace('%C3%A0','à').replace(',','/')
        
        for i in range(len(result)):
            result_link.append('https://pt.wikipedia.org/wiki/' + str(result[i]))
        
        print(result)

    #    resetar variaveis
        dic_frase = {}
        tfidf = 0
        tfidf_acc = 0
        frase_acc = 0

        vet_temp = []
        matriz = []
        for i in range(len(result)): 
            vet_temp.append(result[i])
            vet_temp.append(result_link[i])
            matriz.append(vet_temp)
            vet_temp = []
        print(matriz)
        return render(request,'home.html',{'name2':matriz})
    except Exception as e:
        print('frase ou palavra incorreta')
        print(e)
        return render(request,'home.html',{'name2':result2})


